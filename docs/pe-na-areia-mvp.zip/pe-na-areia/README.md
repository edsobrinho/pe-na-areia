# Pé na Areia

App de entrega sustentável para a orla de Santos, com seleção de local por pin de
geolocalização + postos de referência oficiais, em vez de endereço formal.

## Estrutura do projeto

```
pe-na-areia/
├── backend/     # Java 17 + Spring Boot + MongoDB
└── frontend/    # Flutter (Android/iOS)
```

## O que já está implementado nesta primeira geração

**Backend**
- Models: `User`, `Courier`, `Kiosk`, `ReferencePoint`, `Order`
- Repositórios Spring Data MongoDB (incluindo busca geoespacial `findByLocalizacaoNear`)
- 3 endpoints prioritários:
  - `GET /reference-points` e `GET /reference-points/nearby?lat=&lng=` — postos de salvamento
  - `GET /kiosks` — quiosques/restaurantes parceiros
  - `POST /orders` — criação de pedido com pin de localização
- Seed automático de 4 postos de salvamento de Santos na primeira execução
- Swagger em `/docs`

**Frontend**
- Tela de seleção de localização (`location_selection_screen.dart`): mapa com pin
  arrastável, sugestão automática de postos próximos, descrição do local, foto opcional
- Serviço de API e de geolocalização
- Tema visual básico (cores do mockup)

## O que falta implementar (próximos passos)

- Autenticação (`/auth/login`, `/auth/register`) com JWT — o `SecurityConfig` já
  está com um TODO marcando onde plugar o filtro
- Telas de checkout, acompanhamento e identificação no local (Flutter)
- App do entregador (rota, confirmação de entrega por geolocalização, chat)
- Upload de foto para storage (Firebase Storage) — hoje o campo existe mas não sobe a imagem
- WebSocket/polling para tracking em tempo real do entregador
- Testes unitários dos endpoints críticos

## Como rodar (camadas gratuitas)

### 1. Banco de dados — MongoDB Atlas (free tier M0)
1. Crie uma conta em https://www.mongodb.com/cloud/atlas/register
2. Crie um cluster M0 (gratuito)
3. Copie a connection string e exporte como variável de ambiente:
   ```
   export MONGODB_URI="mongodb+srv://usuario:senha@seu-cluster.mongodb.net"
   export MONGODB_DATABASE="pe_na_areia"
   ```

### 2. Backend
```bash
cd backend
export MONGODB_URI="..."
export JWT_SECRET="algum-segredo-forte"
./mvnw spring-boot:run
```
A API sobe em `http://localhost:8080`, Swagger em `http://localhost:8080/docs`.

Deploy gratuito sugerido: [Render](https://render.com) ou [Railway](https://railway.app)
(ambos com camada free para APIs pequenas).

### 3. Frontend
```bash
cd frontend
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8080
```
> `10.0.2.2` é o endereço do host quando você roda no emulador Android.
> Em iOS Simulator ou dispositivo físico, troque pelo IP real do backend.

Você também vai precisar de uma **chave de API do Google Maps** (nível gratuito
cobre uso de desenvolvimento/baixo volume) configurada em
`android/app/src/main/AndroidManifest.xml` e `ios/Runner/AppDelegate.swift`.

## Notas de arquitetura
- Coordenadas em todo o backend seguem o padrão GeoJSON: `[longitude, latitude]`.
- O pin do pedido fica em `Order.pinCliente`; depois do pagamento, a ideia é travar
  esse campo (`localizacaoTravada = true`) para replicar o comportamento do modelo
  Domino's Pinpoint Delivery — essa trava ainda precisa ser implementada no
  endpoint de pagamento.

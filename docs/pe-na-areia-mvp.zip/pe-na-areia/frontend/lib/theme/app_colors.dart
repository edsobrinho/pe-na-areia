import 'package:flutter/material.dart';

/// Paleta usada nos mockups do "Pe na Areia": tons de oceano, areia e mango.
class AppColors {
  static const ocean900 = Color(0xFF0B3B40);
  static const ocean700 = Color(0xFF135A61);
  static const ocean500 = Color(0xFF1E8A93);
  static const sand50 = Color(0xFFF7F1E2);
  static const sand100 = Color(0xFFEFE2C4);
  static const mango500 = Color(0xFFFF7A3D);
  static const seafoam500 = Color(0xFF4C8C6B);
  static const ink = Color(0xFF12201E);
}

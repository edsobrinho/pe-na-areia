import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';

import '../models/order_location.dart';
import '../models/reference_point.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';
import '../theme/app_colors.dart';

/// Tela 1 do fluxo do cliente: o cliente marca um pin no mapa em vez de
/// digitar um endereco, escolhe o posto de referencia mais proximo e
/// descreve o local. E o nucleo do diferencial do "Pe na Areia".
class LocationSelectionScreen extends StatefulWidget {
  const LocationSelectionScreen({super.key});

  @override
  State<LocationSelectionScreen> createState() =>
      _LocationSelectionScreenState();
}

class _LocationSelectionScreenState extends State<LocationSelectionScreen> {
  final ApiService _api = ApiService();
  final LocationService _locationService = LocationService();
  final TextEditingController _descricaoController = TextEditingController();

  GoogleMapController? _mapController;
  LatLng _pinPosition = const LatLng(-23.9722, -46.3280); // Boqueirao, Santos, fallback inicial

  List<ReferencePoint> _postosProximos = [];
  ReferencePoint? _postoSelecionado;

  File? _fotoLocal;
  bool _carregandoLocalizacao = true;
  bool _confirmando = false;
  String? _erro;

  @override
  void initState() {
    super.initState();
    _inicializarComLocalizacaoAtual();
  }

  @override
  void dispose() {
    _descricaoController.dispose();
    super.dispose();
  }

  Future<void> _inicializarComLocalizacaoAtual() async {
    try {
      final posicao = await _locationService.getCurrentPosition();
      setState(() {
        _pinPosition = LatLng(posicao.latitude, posicao.longitude);
      });
      await _atualizarPostosProximos(_pinPosition);
    } catch (e) {
      // Sem GPS disponivel, mantem o fallback e deixa o usuario mover o pin manualmente.
      setState(() => _erro = e.toString());
      await _atualizarPostosProximos(_pinPosition);
    } finally {
      setState(() => _carregandoLocalizacao = false);
    }
  }

  Future<void> _atualizarPostosProximos(LatLng posicao) async {
    try {
      final postos = await _api.fetchNearbyReferencePoints(
        lat: posicao.latitude,
        lng: posicao.longitude,
      );
      setState(() {
        _postosProximos = postos;
        // Pre-seleciona o mais proximo (primeiro da lista, ordenado pelo backend).
        _postoSelecionado = postos.isNotEmpty ? postos.first : null;
      });
    } catch (e) {
      setState(() => _erro = 'Nao foi possivel carregar os postos de referencia.');
    }
  }

  void _onPinArrastado(LatLng novaPosicao) {
    setState(() => _pinPosition = novaPosicao);
    _atualizarPostosProximos(novaPosicao);
  }

  Future<void> _selecionarFoto() async {
    final picker = ImagePicker();
    final imagem = await picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 1280,
      imageQuality: 80,
    );
    if (imagem != null) {
      setState(() => _fotoLocal = File(imagem.path));
    }
  }

  bool get _podeConfirmar =>
      _postoSelecionado != null &&
      _descricaoController.text.trim().isNotEmpty &&
      !_confirmando;

  Future<void> _confirmarLocalizacao() async {
    if (!_podeConfirmar) return;

    setState(() => _confirmando = true);

    // TODO: fazer upload de _fotoLocal para um storage (ex: Firebase Storage)
    // e obter a URL publica antes de montar o OrderLocation abaixo.
    final location = OrderLocation(
      latitude: _pinPosition.latitude,
      longitude: _pinPosition.longitude,
      pontoReferenciaId: _postoSelecionado!.id,
      descricaoLocal: _descricaoController.text.trim(),
      fotoLocalUrl: null,
    );

    setState(() => _confirmando = false);

    if (!mounted) return;
    Navigator.of(context).pop(location); // Retorna para o fluxo de checkout
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.sand50,
      body: _carregandoLocalizacao
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(flex: 3, child: _buildMapa()),
                Expanded(flex: 4, child: _buildFolhaDeSelecao()),
              ],
            ),
    );
  }

  Widget _buildMapa() {
    return Stack(
      children: [
        GoogleMap(
          initialCameraPosition: CameraPosition(target: _pinPosition, zoom: 17),
          onMapCreated: (controller) => _mapController = controller,
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          markers: {
            Marker(
              markerId: const MarkerId('pin-cliente'),
              position: _pinPosition,
              draggable: true,
              onDragEnd: _onPinArrastado,
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueOrange,
              ),
            ),
            ..._postosProximos.map(
              (posto) => Marker(
                markerId: MarkerId('posto-${posto.id}'),
                position: LatLng(posto.latitude, posto.longitude),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueAzure,
                ),
                infoWindow: InfoWindow(title: posto.nome),
              ),
            ),
          },
        ),
        Positioned(
          top: 12,
          left: 12,
          right: 12,
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.92),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Arraste o pin ate o local exato',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFolhaDeSelecao() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Onde voce esta?',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 18,
                color: AppColors.ocean900,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Escolha o posto de referencia mais proximo e descreva o local',
              style: TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
            const SizedBox(height: 16),
            _buildChipsDePostos(),
            const SizedBox(height: 16),
            TextField(
              controller: _descricaoController,
              maxLength: 140,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText:
                    'Ex: guarda-sol listrado azul, perto do quiosque do Ze',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _selecionarFoto,
              icon: const Icon(Icons.camera_alt_outlined, size: 18),
              label: Text(
                _fotoLocal == null
                    ? 'Adicionar foto do local (opcional)'
                    : 'Foto adicionada',
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.ocean700,
                side: BorderSide(color: AppColors.ocean500.withOpacity(0.5)),
                minimumSize: const Size.fromHeight(44),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            if (_erro != null) ...[
              const SizedBox(height: 10),
              Text(_erro!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _podeConfirmar ? _confirmarLocalizacao : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.mango500,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: _confirmando
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Confirmar localizacao',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChipsDePostos() {
    if (_postosProximos.isEmpty) {
      return const Text(
        'Nenhum posto de referencia encontrado perto do pin. Tente arrastar para mais perto da orla.',
        style: TextStyle(fontSize: 12, color: Colors.black45),
      );
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _postosProximos.map((posto) {
        final selecionado = _postoSelecionado?.id == posto.id;
        return ChoiceChip(
          label: Text(posto.nome),
          selected: selecionado,
          onSelected: (_) => setState(() => _postoSelecionado = posto),
          selectedColor: AppColors.ocean900,
          labelStyle: TextStyle(
            color: selecionado ? Colors.white : AppColors.ocean900,
            fontWeight: FontWeight.w600,
            fontSize: 12.5,
          ),
          backgroundColor: AppColors.sand100,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide.none,
          ),
        );
      }).toList(),
    );
  }
}

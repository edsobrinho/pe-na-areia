class ReferencePoint {
  final String id;
  final int numero;
  final String nome;
  final double latitude;
  final double longitude;
  final String trecho;

  ReferencePoint({
    required this.id,
    required this.numero,
    required this.nome,
    required this.latitude,
    required this.longitude,
    required this.trecho,
  });

  factory ReferencePoint.fromJson(Map<String, dynamic> json) {
    final loc = json['localizacao'] as Map<String, dynamic>;
    final coords = loc['coordinates'] as List<dynamic>; // [lng, lat] no GeoJSON

    return ReferencePoint(
      id: json['id'] as String,
      numero: json['numero'] as int,
      nome: json['nome'] as String,
      longitude: (coords[0] as num).toDouble(),
      latitude: (coords[1] as num).toDouble(),
      trecho: json['trecho'] as String? ?? '',
    );
  }
}

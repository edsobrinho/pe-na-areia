/// Estado da localizacao escolhida pelo cliente na tela de selecao de
/// localizacao. Isso e o que sera enviado para o backend em CreateOrderRequest.
class OrderLocation {
  final double latitude;
  final double longitude;
  final String pontoReferenciaId;
  final String descricaoLocal;
  final String? fotoLocalUrl;

  const OrderLocation({
    required this.latitude,
    required this.longitude,
    required this.pontoReferenciaId,
    required this.descricaoLocal,
    this.fotoLocalUrl,
  });

  Map<String, dynamic> toJson() => {
        'latitude': latitude,
        'longitude': longitude,
        'pontoReferenciaId': pontoReferenciaId,
        'descricaoLocal': descricaoLocal,
        if (fotoLocalUrl != null) 'fotoLocalUrl': fotoLocalUrl,
      };
}

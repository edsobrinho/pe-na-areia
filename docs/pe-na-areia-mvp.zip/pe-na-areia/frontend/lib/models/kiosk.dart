class MenuItem {
  final String id;
  final String nome;
  final double preco;
  final bool disponivel;

  MenuItem({
    required this.id,
    required this.nome,
    required this.preco,
    required this.disponivel,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'] as String,
      nome: json['nome'] as String,
      preco: (json['preco'] as num).toDouble(),
      disponivel: json['disponivel'] as bool? ?? true,
    );
  }
}

class Kiosk {
  final String id;
  final String nome;
  final String pontoReferenciaId;
  final List<MenuItem> cardapio;

  Kiosk({
    required this.id,
    required this.nome,
    required this.pontoReferenciaId,
    required this.cardapio,
  });

  factory Kiosk.fromJson(Map<String, dynamic> json) {
    return Kiosk(
      id: json['id'] as String,
      nome: json['nome'] as String,
      pontoReferenciaId: json['pontoReferenciaId'] as String? ?? '',
      cardapio: (json['cardapio'] as List<dynamic>? ?? [])
          .map((item) => MenuItem.fromJson(item as Map<String, dynamic>))
          .toList(),
    );
  }
}

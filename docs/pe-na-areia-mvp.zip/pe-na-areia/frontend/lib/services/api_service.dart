import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/reference_point.dart';
import '../models/kiosk.dart';

class ApiService {
  // Troque pelo endereco do backend (ex: seu deploy no Render/Railway).
  // Em desenvolvimento local com emulador Android, use 10.0.2.2 no lugar de localhost.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080',
  );

  Future<List<ReferencePoint>> fetchReferencePoints() async {
    final response = await http.get(Uri.parse('$baseUrl/reference-points'));
    _checkOk(response);
    final data = jsonDecode(response.body) as List<dynamic>;
    return data
        .map((json) => ReferencePoint.fromJson(json as Map<String, dynamic>))
        .toList();
  }

  Future<List<ReferencePoint>> fetchNearbyReferencePoints({
    required double lat,
    required double lng,
    double raioKm = 1.5,
  }) async {
    final uri = Uri.parse('$baseUrl/reference-points/nearby').replace(
      queryParameters: {
        'lat': lat.toString(),
        'lng': lng.toString(),
        'raioKm': raioKm.toString(),
      },
    );
    final response = await http.get(uri);
    _checkOk(response);
    final data = jsonDecode(response.body) as List<dynamic>;
    return data
        .map((json) => ReferencePoint.fromJson(json as Map<String, dynamic>))
        .toList();
  }

  Future<List<Kiosk>> fetchKiosks() async {
    final response = await http.get(Uri.parse('$baseUrl/kiosks'));
    _checkOk(response);
    final data = jsonDecode(response.body) as List<dynamic>;
    return data.map((json) => Kiosk.fromJson(json as Map<String, dynamic>)).toList();
  }

  Future<Map<String, dynamic>> createOrder(Map<String, dynamic> body) async {
    final response = await http.post(
      Uri.parse('$baseUrl/orders'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );
    _checkOk(response, expected: 201);
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  void _checkOk(http.Response response, {int expected = 200}) {
    if (response.statusCode != expected) {
      throw Exception(
        'Erro na API (${response.statusCode}): ${response.body}',
      );
    }
  }
}

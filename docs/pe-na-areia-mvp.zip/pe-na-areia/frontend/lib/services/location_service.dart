import 'package:geolocator/geolocator.dart';

class LocationService {
  /// Pede permissao e retorna a posicao atual do dispositivo.
  /// Lanca excecao se o usuario negar a permissao ou o GPS estiver desligado.
  Future<Position> getCurrentPosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Ative o GPS para marcar sua localizacao na praia.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Permissao de localizacao negada.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception(
        'Permissao de localizacao negada permanentemente. Ative nas configuracoes do app.',
      );
    }

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }
}

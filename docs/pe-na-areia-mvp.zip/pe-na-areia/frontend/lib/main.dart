import 'package:flutter/material.dart';

import 'screens/location_selection_screen.dart';
import 'theme/app_colors.dart';

void main() {
  runApp(const PeNaAreiaApp());
}

class PeNaAreiaApp extends StatelessWidget {
  const PeNaAreiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pé na Areia',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.sand50,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.ocean700,
          primary: AppColors.ocean700,
          secondary: AppColors.mango500,
        ),
        fontFamily: 'Roboto',
      ),
      // TODO: trocar pela tela de selecao de quiosque quando ela existir;
      // por enquanto a Location Selection Screen abre direto para teste.
      home: const LocationSelectionScreen(),
    );
  }
}

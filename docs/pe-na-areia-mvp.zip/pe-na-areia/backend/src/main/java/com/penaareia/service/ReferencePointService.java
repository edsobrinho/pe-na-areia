package com.penaareia.service;

import com.penaareia.model.ReferencePoint;
import com.penaareia.repository.ReferencePointRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResult;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metrics;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReferencePointService {

    private final ReferencePointRepository repository;

    public List<ReferencePoint> listarAtivos() {
        return repository.findByAtivoTrue();
    }

    /**
     * Sugere o posto de referencia mais proximo de um pin, usado na tela
     * de selecao de localizacao para pre-selecionar o chip mais provavel.
     */
    public List<ReferencePoint> sugerirProximos(double latitude, double longitude, double raioKm) {
        GeoJsonPoint ponto = new GeoJsonPoint(longitude, latitude);
        GeoResults<ReferencePoint> resultados =
                repository.findByLocalizacaoNear(ponto, new Distance(raioKm, Metrics.KILOMETERS));

        return resultados.getContent().stream()
                .map(GeoResult::getContent)
                .toList();
    }
}

package com.penaareia.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Configuracao inicial: libera os endpoints publicos do catalogo (postos de
 * referencia, quiosques, docs) e deixa o resto pronto para receber o filtro
 * JWT quando /auth/login e /auth/register forem implementados.
 *
 * TODO: adicionar JwtAuthenticationFilter antes de UsernamePasswordAuthenticationFilter
 * e restringir POST /orders e PATCH /orders/** a usuarios autenticados.
 */
@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/docs/**", "/api-docs/**", "/swagger-ui/**").permitAll()
                        .requestMatchers("/auth/**").permitAll()
                        .requestMatchers("/reference-points/**", "/kiosks/**").permitAll()
                        .anyRequest().permitAll() // TODO: trocar para .authenticated() quando o JWT estiver plugado
                );

        return http.build();
    }
}

package com.penaareia.dto;

import com.penaareia.model.PaymentMethod;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class CreateOrderRequest {

    @NotBlank
    private String userId;

    @NotBlank
    private String kioskId;

    @NotEmpty(message = "O pedido precisa ter ao menos um item")
    private List<ItemRequest> itens;

    @NotNull
    private PaymentMethod formaPagamento;

    private boolean embalagemSustentavel;

    // --- Localizacao ---
    @NotNull(message = "Latitude do pin e obrigatoria")
    private Double latitude;

    @NotNull(message = "Longitude do pin e obrigatoria")
    private Double longitude;

    @NotBlank(message = "Selecione o posto de referencia mais proximo")
    private String pontoReferenciaId;

    @NotBlank(message = "Descreva o local para o entregador te encontrar")
    private String descricaoLocal;

    /** Opcional - URL da foto ja enviada para o storage */
    private String fotoLocalUrl;

    @Data
    public static class ItemRequest {
        @NotBlank
        private String menuItemId;

        @NotNull
        private Integer quantidade;
    }
}

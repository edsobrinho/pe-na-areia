package com.penaareia.dto;

import com.penaareia.model.Order;
import com.penaareia.model.OrderStatus;
import com.penaareia.model.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponse {

    private String id;
    private double valorTotal;
    private OrderStatus status;
    private PaymentMethod formaPagamento;
    private boolean embalagemSustentavel;
    private String pontoReferenciaId;
    private String descricaoLocal;
    private List<Order.OrderItem> itens;

    public static OrderResponse fromEntity(Order order) {
        return new OrderResponse(
                order.getId(),
                order.getValorTotal(),
                order.getStatus(),
                order.getFormaPagamento(),
                order.isEmbalagemSustentavel(),
                order.getPontoReferenciaId(),
                order.getDescricaoLocal(),
                order.getItens()
        );
    }
}

package com.penaareia.controller;

import com.penaareia.dto.CreateOrderRequest;
import com.penaareia.dto.OrderResponse;
import com.penaareia.model.Order;
import com.penaareia.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
@Tag(name = "Pedidos", description = "Criacao e consulta de pedidos, incluindo pin de localizacao")
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    @Operation(summary = "Cria um pedido com pin de localizacao, itens e forma de pagamento")
    public ResponseEntity<OrderResponse> criar(@Valid @RequestBody CreateOrderRequest request) {
        Order order = orderService.criarPedido(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(OrderResponse.fromEntity(order));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca um pedido pelo id")
    public OrderResponse buscar(@PathVariable String id) {
        return OrderResponse.fromEntity(orderService.buscarPorId(id));
    }
}

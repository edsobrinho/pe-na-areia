package com.penaareia.service;

import com.penaareia.dto.CreateOrderRequest;
import com.penaareia.model.Kiosk;
import com.penaareia.model.Order;
import com.penaareia.repository.KioskRepository;
import com.penaareia.repository.OrderRepository;
import com.penaareia.repository.ReferencePointRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final KioskRepository kioskRepository;
    private final ReferencePointRepository referencePointRepository;

    public Order criarPedido(CreateOrderRequest request) {
        Kiosk kiosk = kioskRepository.findById(request.getKioskId())
                .orElseThrow(() -> new ResourceNotFoundException("Quiosque nao encontrado: " + request.getKioskId()));

        if (!referencePointRepository.existsById(request.getPontoReferenciaId())) {
            throw new ResourceNotFoundException("Posto de referencia nao encontrado: " + request.getPontoReferenciaId());
        }

        Map<String, Kiosk.MenuItem> cardapioPorId = kiosk.getCardapio().stream()
                .collect(Collectors.toMap(Kiosk.MenuItem::getId, item -> item));

        List<Order.OrderItem> itens = request.getItens().stream()
                .map(itemReq -> {
                    Kiosk.MenuItem menuItem = cardapioPorId.get(itemReq.getMenuItemId());
                    if (menuItem == null || !menuItem.isDisponivel()) {
                        throw new ResourceNotFoundException(
                                "Item indisponivel no cardapio: " + itemReq.getMenuItemId());
                    }
                    return new Order.OrderItem(
                            menuItem.getId(),
                            menuItem.getNome(),
                            itemReq.getQuantidade(),
                            menuItem.getPreco()
                    );
                })
                .toList();

        double valorTotal = itens.stream()
                .mapToDouble(item -> item.getPrecoUnitario() * item.getQuantidade())
                .sum();

        Order order = new Order();
        order.setUserId(request.getUserId());
        order.setKioskId(request.getKioskId());
        order.setItens(itens);
        order.setValorTotal(valorTotal);
        order.setFormaPagamento(request.getFormaPagamento());
        order.setEmbalagemSustentavel(request.isEmbalagemSustentavel());

        // GeoJsonPoint espera (longitude, latitude), nessa ordem
        order.setPinCliente(new GeoJsonPoint(request.getLongitude(), request.getLatitude()));
        order.setPontoReferenciaId(request.getPontoReferenciaId());
        order.setDescricaoLocal(request.getDescricaoLocal());
        order.setFotoLocalUrl(request.getFotoLocalUrl());

        return orderRepository.save(order);
    }

    public Order buscarPorId(String id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido nao encontrado: " + id));
    }
}

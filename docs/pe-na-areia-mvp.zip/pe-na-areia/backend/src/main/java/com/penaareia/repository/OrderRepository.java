package com.penaareia.repository;

import com.penaareia.model.Order;
import com.penaareia.model.OrderStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface OrderRepository extends MongoRepository<Order, String> {

    List<Order> findByUserIdOrderByTimelineCriadoEmDesc(String userId);

    List<Order> findByCourierIdAndStatus(String courierId, OrderStatus status);

    List<Order> findByStatus(OrderStatus status);
}

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';

import '../../data/api/api_client.dart';
import '../../data/repositories/reference_point_repository.dart';
import '../../domain/models/geo_point.dart';
import '../../domain/models/reference_point.dart';

/// Tela de seleção de localização (MVP — funcionalidade 2):
/// mapa com pin arrastável, sugestão automática do posto de salvamento
/// mais próximo, descrição curta do local e foto opcional.
class LocationSelectionPage extends StatefulWidget {
  const LocationSelectionPage({super.key});

  @override
  State<LocationSelectionPage> createState() => _LocationSelectionPageState();
}

class _LocationSelectionPageState extends State<LocationSelectionPage> {
  // Orla de Santos — posição inicial padrão
  static const _initial = LatLng(-23.9810, -46.3180);

  final _mapController = Completer<GoogleMapController>();
  final _descriptionController = TextEditingController();
  final _repository = ReferencePointRepository(ApiClient());

  LatLng _pin = _initial;
  List<ReferencePoint> _nearbyPosts = [];
  ReferencePoint? _selectedPost;
  XFile? _photo;
  bool _loadingLocation = true;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  Future<void> _initLocation() async {
    GeoPoint center = const GeoPoint(_initial.latitude, _initial.longitude);
    try {
      final position = await _determinePosition();
      final userPos = LatLng(position.latitude, position.longitude);
      setState(() => _pin = userPos);
      center = GeoPoint(userPos.latitude, userPos.longitude);
      final controller = await _mapController.future;
      controller.animateCamera(CameraUpdate.newLatLngZoom(userPos, 16));
    } catch (_) {
      // Sem GPS: mantém o pin no ponto inicial padrão da orla
    }
    await _loadNearbyPosts(center);
    if (mounted) setState(() => _loadingLocation = false);
  }

  Future<Position> _determinePosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw Exception('GPS desativado');
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw Exception('Permissão de localização negada');
    }
    return Geolocator.getCurrentPosition();
  }

  Future<void> _loadNearbyPosts(GeoPoint from) async {
    final posts = await _repository.findNear(from);
    if (!mounted) return;
    setState(() {
      _nearbyPosts = posts;
      // Sugestão automática: posto mais próximo do pin atual
      _selectedPost = posts.isEmpty ? null : posts.first;
    });
  }

  /// Chamado enquanto o usuário arrasta o mapa (o pin fica fixo no centro).
  void _onCameraMove(CameraPosition position) {
    _pin = position.target;
    // Debounce: recalcula o posto sugerido só quando o arraste parar
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), _suggestNearestPost);
  }

  void _suggestNearestPost() {
    if (_nearbyPosts.isEmpty) return;
    ReferencePoint? nearest;
    double minDistance = double.infinity;
    for (final post in _nearbyPosts) {
      final d = _distanceMeters(
        _pin.latitude, _pin.longitude,
        post.location.lat, post.location.lng,
      );
      if (d < minDistance) {
        minDistance = d;
        nearest = post;
      }
    }
    if (nearest != null && nearest.id != _selectedPost?.id) {
      setState(() => _selectedPost = nearest);
    }
  }

  double _distanceMeters(double lat1, double lng1, double lat2, double lng2) {
    const earthRadius = 6371000.0;
    final dLat = _rad(lat2 - lat1);
    final dLng = _rad(lng2 - lng1);
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_rad(lat1)) * math.cos(_rad(lat2)) *
            math.sin(dLng / 2) * math.sin(dLng / 2);
    return earthRadius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  double _rad(double deg) => deg * math.pi / 180;

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final photo =
        await picker.pickImage(source: ImageSource.camera, imageQuality: 70);
    if (photo != null) setState(() => _photo = photo);
  }

  void _confirmLocation() {
    // TODO: navegar para o checkout passando
    // DeliveryLocation(pin: _pin, referencePoint: _selectedPost, ...)
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
        'Pin: ${_pin.latitude.toStringAsFixed(5)}, ${_pin.longitude.toStringAsFixed(5)} '
        '| Ref: ${_selectedPost?.name ?? 'nenhum'}',
      ),
    ));
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Onde você está na praia?')),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition:
                const CameraPosition(target: _initial, zoom: 16),
            onMapCreated: (c) => _mapController.complete(c),
            onCameraMove: _onCameraMove,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            // Marcadores dos postos de salvamento próximos
            markers: _nearbyPosts
                .map((p) => Marker(
                      markerId: MarkerId(p.id),
                      position: LatLng(p.location.lat, p.location.lng),
                      infoWindow: InfoWindow(title: p.name),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                          BitmapDescriptor.hueAzure),
                    ))
                .toSet(),
          ),
          // Pin central fixo — arrastar o mapa move o pin
          const Center(
            child: Padding(
              padding: EdgeInsets.only(bottom: 40),
              child:
                  Icon(Icons.location_pin, size: 52, color: Colors.redAccent),
            ),
          ),
          if (_loadingLocation)
            const Center(child: CircularProgressIndicator()),
          // Painel inferior: referência + descrição + foto
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: const [
                  BoxShadow(blurRadius: 8, color: Colors.black26)
                ],
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    DropdownButtonFormField<ReferencePoint>(
                      value: _selectedPost,
                      decoration: const InputDecoration(
                        labelText: 'Posto de referência mais próximo',
                        prefixIcon: Icon(Icons.beach_access),
                        border: OutlineInputBorder(),
                      ),
                      items: _nearbyPosts
                          .map((p) =>
                              DropdownMenuItem(value: p, child: Text(p.name)))
                          .toList(),
                      onChanged: (p) => setState(() => _selectedPost = p),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _descriptionController,
                      maxLength: 200,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: 'Descreva seu local (ex.: sombrinha azul)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    Row(
                      children: [
                        OutlinedButton.icon(
                          onPressed: _pickPhoto,
                          icon: const Icon(Icons.photo_camera_outlined),
                          label: Text(_photo == null
                              ? 'Foto do local (opcional)'
                              : 'Foto ✓'),
                        ),
                        const Spacer(),
                        FilledButton.icon(
                          onPressed:
                              _selectedPost == null ? null : _confirmLocation,
                          icon: const Icon(Icons.check),
                          label: const Text('Confirmar local'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../data/api/api_client.dart';
import '../../data/auth/token_storage.dart';
import '../../data/repositories/auth_repository.dart';
import '../location/location_selection_page.dart';

/// Login/Cadastro unificado. Após autenticar, clientes vão para a
/// seleção de localização; entregadores irão para a lista de pedidos.
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _auth = AuthRepository(ApiClient(), TokenStorage());

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isRegisterMode = false;
  bool _isCourier = false;
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final session = _isRegisterMode
          ? await _auth.register(
              name: _nameController.text.trim(),
              email: _emailController.text.trim(),
              phone: _phoneController.text.trim(),
              password: _passwordController.text,
              role: _isCourier ? 'COURIER' : 'CLIENT',
              vehicle: _isCourier ? 'PE' : null,
            )
          : await _auth.login(
              _emailController.text.trim(), _passwordController.text);

      if (!mounted) return;
      // TODO: COURIER -> OrdersAvailablePage; CLIENT -> fluxo normal
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => const LocationSelectionPage()));
    } catch (e) {
      setState(() => _error = 'Falha na autenticação. Verifique os dados.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.beach_access,
                      size: 64, color: Color(0xFF00796B)),
                  const SizedBox(height: 8),
                  Text('Pé na Areia',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 24),
                  if (_isRegisterMode) ...[
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                          labelText: 'Nome', border: OutlineInputBorder()),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? 'Informe o nome' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                          labelText: 'Telefone', border: OutlineInputBorder()),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? 'Informe o telefone' : null,
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                        labelText: 'E-mail', border: OutlineInputBorder()),
                    validator: (v) => (v == null || !v.contains('@'))
                        ? 'E-mail inválido'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                        labelText: 'Senha', border: OutlineInputBorder()),
                    validator: (v) =>
                        (v == null || v.length < 6) ? 'Mínimo 6 caracteres' : null,
                  ),
                  if (_isRegisterMode) ...[
                    const SizedBox(height: 12),
                    SwitchListTile(
                      title: const Text('Sou entregador'),
                      subtitle: const Text('PE ou BIKE'),
                      value: _isCourier,
                      onChanged: (v) => setState(() => _isCourier = v),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!,
                        style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _loading ? null : _submit,
                    child: _loading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(_isRegisterMode ? 'Criar conta' : 'Entrar'),
                  ),
                  TextButton(
                    onPressed: () => setState(
                        () => _isRegisterMode = !_isRegisterMode),
                    child: Text(_isRegisterMode
                        ? 'Já tenho conta'
                        : 'Criar conta'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}

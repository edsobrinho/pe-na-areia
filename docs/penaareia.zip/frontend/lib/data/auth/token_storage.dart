import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../domain/models/auth_session.dart';

/// Persiste a sessão JWT no Keychain (iOS) / Keystore (Android).
class TokenStorage {
  static const _keyToken = 'auth_token';
  static const _keyUserId = 'auth_user_id';
  static const _keyName = 'auth_name';
  static const _keyRole = 'auth_role';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  Future<void> save(AuthSession session) async {
    await _storage.write(key: _keyToken, value: session.token);
    await _storage.write(key: _keyUserId, value: session.userId);
    await _storage.write(key: _keyName, value: session.name);
    await _storage.write(key: _keyRole, value: session.role);
  }

  Future<AuthSession?> read() async {
    final token = await _storage.read(key: _keyToken);
    if (token == null) return null;
    return AuthSession(
      token: token,
      userId: await _storage.read(key: _keyUserId) ?? '',
      name: await _storage.read(key: _keyName) ?? '',
      role: await _storage.read(key: _keyRole) ?? 'CLIENT',
    );
  }

  Future<void> clear() async {
    await _storage.delete(key: _keyToken);
    await _storage.delete(key: _keyUserId);
    await _storage.delete(key: _keyName);
    await _storage.delete(key: _keyRole);
  }
}

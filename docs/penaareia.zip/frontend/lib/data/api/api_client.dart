import 'package:dio/dio.dart';

/// Cliente HTTP central. Aponte a baseUrl para o backend hospedado
/// (Render/Railway) ou para 10.0.2.2:8080 no emulador Android.
class ApiClient {
  final Dio dio;

  ApiClient({String? baseUrl})
      : dio = Dio(BaseOptions(
          baseUrl: baseUrl ??
              const String.fromEnvironment('API_BASE_URL',
                  defaultValue: 'http://10.0.2.2:8080'),
          connectTimeout: const Duration(seconds: 10),
          receiveTimeout: const Duration(seconds: 10),
        ));
}

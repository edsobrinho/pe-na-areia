import 'package:dio/dio.dart';

import '../auth/token_storage.dart';

/// Injeta o header Authorization: Bearer <token> em todas as requisições
/// e desloga automaticamente em caso de 401.
class AuthInterceptor extends Interceptor {
  final TokenStorage _tokenStorage;
  final void Function() onUnauthorized;

  AuthInterceptor(this._tokenStorage, {required this.onUnauthorized});

  @override
  void onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    final session = await _tokenStorage.read();
    if (session != null) {
      options.headers['Authorization'] = 'Bearer ${session.token}';
    }
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    if (err.response?.statusCode == 401) {
      onUnauthorized();
    }
    handler.next(err);
  }
}

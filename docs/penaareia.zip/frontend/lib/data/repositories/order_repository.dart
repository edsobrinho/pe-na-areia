import '../../domain/models/geo_point.dart';
import '../../domain/models/order.dart';
import '../api/api_client.dart';

class CreateOrderPayload {
  final String userId;
  final String kioskId;
  final List<OrderItem> items;
  final PaymentMethod paymentMethod;
  final GeoPoint deliveryPin;
  final String referencePointId;
  final String? locationDescription;
  final String? locationPhotoUrl;
  final bool sustainablePackaging;

  const CreateOrderPayload({
    required this.userId,
    required this.kioskId,
    required this.items,
    required this.paymentMethod,
    required this.deliveryPin,
    required this.referencePointId,
    this.locationDescription,
    this.locationPhotoUrl,
    required this.sustainablePackaging,
  });

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'kioskId': kioskId,
        'items': items.map((e) => e.toJson()).toList(),
        'paymentMethod': paymentMethod.name,
        'deliveryPin': deliveryPin.toJson(),
        'referencePointId': referencePointId,
        'locationDescription': locationDescription,
        'locationPhotoUrl': locationPhotoUrl,
        'sustainablePackaging': sustainablePackaging,
      };
}

class OrderRepository {
  final ApiClient _api;

  OrderRepository(this._api);

  Future<Order> createOrder(CreateOrderPayload payload) async {
    final response =
        await _api.dio.post('/orders', data: payload.toJson());
    return Order.fromJson(response.data as Map<String, dynamic>);
  }

  Future<Order> updateStatus(String orderId, OrderStatus status) async {
    final response = await _api.dio.patch('/orders/$orderId/status',
        data: {'status': status.name});
    return Order.fromJson(response.data as Map<String, dynamic>);
  }

  /// Confirma entrega — o app envia a localização atual do entregador;
  /// o backend valida o raio em relação ao pin do cliente.
  Future<Order> confirmDelivery(
      String orderId, String courierId, GeoPoint courierLocation) async {
    final response =
        await _api.dio.post('/orders/$orderId/confirm-delivery', data: {
      'courierId': courierId,
      'courierLocation': courierLocation.toJson(),
    });
    return Order.fromJson(response.data as Map<String, dynamic>);
  }
}

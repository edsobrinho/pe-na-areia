import '../../domain/models/geo_point.dart';
import '../../domain/models/reference_point.dart';
import '../api/api_client.dart';

class ReferencePointRepository {
  final ApiClient _api;

  ReferencePointRepository(this._api);

  Future<List<ReferencePoint>> findNear(GeoPoint from,
      {int radiusMeters = 3000}) async {
    final response = await _api.dio.get('/reference-points', queryParameters: {
      'lat': from.lat,
      'lng': from.lng,
      'radiusMeters': radiusMeters,
    });
    return (response.data as List)
        .map((e) => ReferencePoint.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}

import '../../domain/models/auth_session.dart';
import '../api/api_client.dart';
import '../auth/token_storage.dart';

class AuthRepository {
  final ApiClient _api;
  final TokenStorage _tokenStorage;

  AuthRepository(this._api, this._tokenStorage);

  Future<AuthSession> login(String email, String password) async {
    final response = await _api.dio.post('/auth/login', data: {
      'email': email,
      'password': password,
    });
    final session = AuthSession.fromJson(response.data as Map<String, dynamic>);
    await _tokenStorage.save(session);
    return session;
  }

  Future<AuthSession> register({
    required String name,
    required String email,
    required String phone,
    required String password,
    required String role, // CLIENT ou COURIER
    String? vehicle,      // PE/BIKE, só para COURIER
  }) async {
    final response = await _api.dio.post('/auth/register', data: {
      'name': name,
      'email': email,
      'phone': phone,
      'password': password,
      'role': role,
      'vehicle': vehicle,
    });
    final session = AuthSession.fromJson(response.data as Map<String, dynamic>);
    await _tokenStorage.save(session);
    return session;
  }

  Future<AuthSession?> currentSession() => _tokenStorage.read();

  Future<void> logout() => _tokenStorage.clear();
}

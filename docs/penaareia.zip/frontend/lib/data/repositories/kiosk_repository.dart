import '../../domain/models/geo_point.dart';
import '../../domain/models/kiosk.dart';
import '../api/api_client.dart';

class KioskRepository {
  final ApiClient _api;

  KioskRepository(this._api);

  Future<List<Kiosk>> findNear(GeoPoint from, {int radiusMeters = 5000}) async {
    final response = await _api.dio.get('/kiosks', queryParameters: {
      'lat': from.lat,
      'lng': from.lng,
      'radiusMeters': radiusMeters,
    });
    return (response.data as List)
        .map((e) => Kiosk.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}

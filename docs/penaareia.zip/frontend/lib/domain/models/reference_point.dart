import 'geo_point.dart';

class ReferencePoint {
  final String id;
  final int number;
  final String name;
  final GeoPoint location;

  const ReferencePoint({
    required this.id,
    required this.number,
    required this.name,
    required this.location,
  });

  factory ReferencePoint.fromJson(Map<String, dynamic> json) => ReferencePoint(
        id: json['id'] as String,
        number: json['number'] as int,
        name: json['name'] as String,
        location: GeoPoint.fromJson(json['location'] as Map<String, dynamic>),
      );
}

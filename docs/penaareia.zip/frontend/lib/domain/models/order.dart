import 'geo_point.dart';

enum OrderStatus { CREATED, PAID, PREPARING, ON_THE_WAY, DELIVERED, CANCELLED }

enum PaymentMethod { PIX, CREDIT_CARD }

class OrderItem {
  final String menuItemId;
  final String name;
  final double unitPrice;
  final int quantity;

  const OrderItem({
    required this.menuItemId,
    required this.name,
    required this.unitPrice,
    required this.quantity,
  });

  Map<String, dynamic> toJson() => {
        'menuItemId': menuItemId,
        'name': name,
        'unitPrice': unitPrice,
        'quantity': quantity,
      };
}

class Order {
  final String id;
  final String userId;
  final String kioskId;
  final List<OrderItem> items;
  final double totalAmount;
  final PaymentMethod paymentMethod;
  final OrderStatus status;
  final GeoPoint deliveryPin;
  final String referencePointId;
  final String? locationDescription;
  final String? locationPhotoUrl;
  final bool sustainablePackaging;
  final String? courierId;

  const Order({
    required this.id,
    required this.userId,
    required this.kioskId,
    required this.items,
    required this.totalAmount,
    required this.paymentMethod,
    required this.status,
    required this.deliveryPin,
    required this.referencePointId,
    this.locationDescription,
    this.locationPhotoUrl,
    required this.sustainablePackaging,
    this.courierId,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json['id'] as String,
        userId: json['userId'] as String,
        kioskId: json['kioskId'] as String,
        items: (json['items'] as List)
            .map((e) => OrderItem(
                  menuItemId: e['menuItemId'] as String,
                  name: e['name'] as String,
                  unitPrice: (e['unitPrice'] as num).toDouble(),
                  quantity: e['quantity'] as int,
                ))
            .toList(),
        totalAmount: (json['totalAmount'] as num).toDouble(),
        paymentMethod: PaymentMethod.values.byName(json['paymentMethod'] as String),
        status: OrderStatus.values.byName(json['status'] as String),
        deliveryPin: GeoPoint.fromJson(json['deliveryPin'] as Map<String, dynamic>),
        referencePointId: json['referencePointId'] as String,
        locationDescription: json['locationDescription'] as String?,
        locationPhotoUrl: json['locationPhotoUrl'] as String?,
        sustainablePackaging: json['sustainablePackaging'] as bool,
        courierId: json['courierId'] as String?,
      );
}

/// Sessão autenticada retornada por /auth/login e /auth/register.
class AuthSession {
  final String token;
  final String userId;
  final String name;
  final String role; // CLIENT ou COURIER

  const AuthSession({
    required this.token,
    required this.userId,
    required this.name,
    required this.role,
  });

  bool get isCourier => role == 'COURIER';

  factory AuthSession.fromJson(Map<String, dynamic> json) => AuthSession(
        token: json['token'] as String,
        userId: json['userId'] as String,
        name: json['name'] as String,
        role: json['role'] as String,
      );
}

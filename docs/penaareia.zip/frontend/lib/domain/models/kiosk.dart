import 'geo_point.dart';

class Kiosk {
  final String id;
  final String name;
  final String nearestReferencePointId;
  final GeoPoint location;

  const Kiosk({
    required this.id,
    required this.name,
    required this.nearestReferencePointId,
    required this.location,
  });

  factory Kiosk.fromJson(Map<String, dynamic> json) => Kiosk(
        id: json['id'] as String,
        name: json['name'] as String,
        nearestReferencePointId: json['nearestReferencePointId'] as String,
        location: GeoPoint.fromJson(json['location'] as Map<String, dynamic>),
      );
}

import 'package:flutter/material.dart';
import 'presentation/auth/login_page.dart';

void main() {
  runApp(const PenaAreiaApp());
}

class PenaAreiaApp extends StatelessWidget {
  const PenaAreiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pé na Areia',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00796B)),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

import 'package:flutter_test/flutter_test.dart';
import 'package:penaareia/domain/models/geo_point.dart';

void main() {
  test('serializa e desserializa GeoPoint', () {
    const point = GeoPoint(-23.9810, -46.3180);
    final restored = GeoPoint.fromJson(point.toJson());
    expect(restored.lat, point.lat);
    expect(restored.lng, point.lng);
  });
}

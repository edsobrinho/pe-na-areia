# Pé na Areia 🏖️

App de entrega sustentável para a orla de Santos — entrega na praia via pin de
geolocalização + posto de salvamento como ponto de referência.

## Estrutura

```
penaareia/
├── backend/    Java 17 + Spring Boot 3 + Spring Data MongoDB (Atlas M0) + JWT
└── frontend/   Flutter (Android/iOS) — Google Maps, geolocator, dio, FCM
```

## Backend — como rodar

1. Crie um cluster M0 no MongoDB Atlas e copie a URI.
2. `export MONGODB_URI="mongodb+srv://..."`
   (opcional: `export JWT_SECRET=<base64 com 32+ bytes>`)
3. `cd backend && ./mvnw spring-boot:run` (ou `mvn spring-boot:run`)
4. Swagger UI: http://localhost:8080/swagger-ui.html

O seed dos postos de salvamento roda automaticamente na primeira execução
(`ReferencePointDataLoader`). Testes: `mvn test`.

## Autenticação (JWT)

Todos os endpoints (exceto `/auth/**` e Swagger) exigem o header
`Authorization: Bearer <token>`. O token carrega o id do usuário (subject) e a
role (`CLIENT` ou `COURIER`). Cadastro/login unificados:

```
POST /auth/register   {name, email, phone, password, role: CLIENT|COURIER, vehicle?}
POST /auth/login      {email, password}
→ 200 {token, userId, name, role}
```

## Endpoints implementados

| Método | Rota | Descrição |
|---|---|---|
| POST | /auth/register | Cadastra cliente ou entregador, retorna JWT |
| POST | /auth/login | Autentica, retorna JWT |
| POST | /orders | Cria pedido com pin; valida distância pin↔posto (máx. 500 m) |
| GET | /reference-points | Lista postos; com `lat,lng,radiusMeters` retorna os mais próximos |
| GET | /kiosks | Lista quiosques; com `lat,lng,radiusMeters` retorna os mais próximos |
| PATCH | /orders/{id}/status | Máquina de transições: PAID→PREPARING→ON_THE_WAY→DELIVERED (cancelável até PREPARING) |
| POST | /orders/{id}/confirm-delivery | Exige geolocalização do entregador dentro do raio do pin (`penaareia.delivery.radius-meters`, default 50 m) |

## Regras de negócio implementadas

- **Pagamento antecipado**: pedido nasce com status `PAID` (gateway Pix/cartão entra depois)
- **Consistência pin↔posto**: pin a mais de 500 m do posto vinculado é rejeitado (422)
- **Máquina de estados**: transições inválidas rejeitadas (ex.: DELIVERED → PREPARING)
- **Confirmação geolocalizada**: só o courier vinculado confirma, e apenas dentro do raio;
  ao confirmar, o entregador volta para AVAILABLE

## Frontend — como rodar

1. `cd frontend && flutter pub get`
2. Adicione a chave do Google Maps (AndroidManifest.xml / AppDelegate.swift)
   conforme a documentação do google_maps_flutter.
3. `flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8080`
   (10.0.2.2 = localhost visto do emulador Android)

O app abre na tela de login/cadastro; o token JWT fica no
flutter_secure_storage (Keychain/Keystore) e é injetado automaticamente nas
requisições pelo `AuthInterceptor`.

## Próximos passos sugeridos

1. WebSocket (STOMP) ou polling para tracking do entregador
   (GET /orders/{id}/tracking + atualização de currentLocation do courier)
2. Firebase Cloud Messaging nos marcos de status do pedido
3. Upload da foto do local para Firebase Storage
4. App do entregador: pedidos disponíveis com distância, rota Google Maps,
   confirmação de entrega (endpoint pronto) e chat simples

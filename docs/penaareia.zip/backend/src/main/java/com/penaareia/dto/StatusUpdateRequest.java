package com.penaareia.dto;

import com.penaareia.model.Order;
import jakarta.validation.constraints.NotNull;

public record StatusUpdateRequest(
        @NotNull Order.Status status
) {
}

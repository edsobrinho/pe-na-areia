package com.penaareia.dto;

import com.penaareia.model.GeoPoint;
import com.penaareia.model.Order;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public record CreateOrderRequest(
        @NotBlank String userId,
        @NotBlank String kioskId,
        @NotEmpty @Valid List<OrderItemRequest> items,

        @NotNull Order.PaymentMethod paymentMethod,

        @NotNull GeoPoint deliveryPin,

        @NotBlank String referencePointId,

        @Size(max = 200) String locationDescription,

        String locationPhotoUrl,

        boolean sustainablePackaging
) {
}

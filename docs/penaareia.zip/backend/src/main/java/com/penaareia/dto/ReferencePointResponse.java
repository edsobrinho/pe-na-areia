package com.penaareia.dto;

import com.penaareia.model.GeoPoint;
import com.penaareia.model.ReferencePoint;

public record ReferencePointResponse(
        String id,
        Integer number,
        String name,
        GeoPoint location
) {

    public static ReferencePointResponse from(ReferencePoint rp) {
        return new ReferencePointResponse(
                rp.getId(), rp.getNumber(), rp.getName(),
                new GeoPoint(rp.getLocation().getY(), rp.getLocation().getX())
        );
    }
}

package com.penaareia.repository;

import com.penaareia.model.Kiosk;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface KioskRepository extends MongoRepository<Kiosk, String> {
    /** Quiosques num raio (metros), mais proximos primeiro. */
    @org.springframework.data.mongodb.repository.Query("{ 'location': { $near: { $geometry: ?0, $maxDistance: ?1 } } }")
    java.util.List<Kiosk> findNear(org.springframework.data.mongodb.core.geo.GeoJsonPoint point, int maxDistanceMeters);
}

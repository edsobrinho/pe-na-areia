package com.penaareia.service;

import com.penaareia.dto.AuthDtos.AuthResponse;
import com.penaareia.dto.AuthDtos.LoginRequest;
import com.penaareia.dto.AuthDtos.RegisterRequest;
import com.penaareia.dto.AuthDtos.Role;
import com.penaareia.model.Courier;
import com.penaareia.model.User;
import com.penaareia.repository.CourierRepository;
import com.penaareia.repository.UserRepository;
import com.penaareia.security.JwtService;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final CourierRepository courierRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
                       CourierRepository courierRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.courierRepository = courierRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public AuthResponse register(RegisterRequest request) {
        Role role = parseRole(request.role());
        String hash = passwordEncoder.encode(request.password());

        if (role == Role.CLIENT) {
            try {
                User user = userRepository.save(
                        new User(request.name(), request.email(), request.phone(), hash));
                return new AuthResponse(
                        jwtService.generateToken(user.getId(), user.getEmail(), "CLIENT"),
                        user.getId(), user.getName(), "CLIENT");
            } catch (DuplicateKeyException e) {
                throw new BusinessRuleException("E-mail ou telefone já cadastrado.");
            }
        }

        // COURIER
        if (request.vehicle() == null || request.vehicle().isBlank()) {
            throw new BusinessRuleException("Informe o veículo do entregador (PE ou BIKE).");
        }
        try {
            Courier courier = new Courier(request.name(), request.vehicle());
            courier.setEmail(request.email());
            courier.setPasswordHash(hash);
            courier = courierRepository.save(courier);
            return new AuthResponse(
                    jwtService.generateToken(courier.getId(), request.email(), "COURIER"),
                    courier.getId(), courier.getName(), "COURIER");
        } catch (DuplicateKeyException e) {
            throw new BusinessRuleException("E-mail já cadastrado.");
        }
    }

    public AuthResponse login(LoginRequest request) {
        var user = userRepository.findByEmail(request.email());
        if (user.isPresent()
                && passwordEncoder.matches(request.password(), user.get().getPasswordHash())) {
            User u = user.get();
            return new AuthResponse(
                    jwtService.generateToken(u.getId(), u.getEmail(), "CLIENT"),
                    u.getId(), u.getName(), "CLIENT");
        }

        var courier = courierRepository.findByEmail(request.email());
        if (courier.isPresent()
                && courier.get().getPasswordHash() != null
                && passwordEncoder.matches(request.password(), courier.get().getPasswordHash())) {
            Courier c = courier.get();
            return new AuthResponse(
                    jwtService.generateToken(c.getId(), request.email(), "COURIER"),
                    c.getId(), c.getName(), "COURIER");
        }

        throw new BusinessRuleException("Credenciais inválidas.");
    }

    private Role parseRole(String role) {
        try {
            return Role.valueOf(role.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BusinessRuleException("Role inválida: " + role + " (use CLIENT ou COURIER).");
        }
    }
}

package com.penaareia.config;

import com.penaareia.model.ReferencePoint;
import com.penaareia.repository.ReferencePointRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;

import java.util.List;

/**
 * Seed inicial dos postos de salvamento da orla de Santos.
 * Só insere se a collection estiver vazia.
 * Coordenadas aproximadas — ajuste para os pontos oficiais.
 */
@Configuration
public class ReferencePointDataLoader {

    @Bean
    CommandLineRunner seedReferencePoints(ReferencePointRepository repository) {
        return args -> {
            if (repository.count() > 0) {
                return;
            }
            repository.saveAll(List.of(
                    new ReferencePoint(1, "Posto 1 - Boqueirão", point(-23.9660, -46.3330)),
                    new ReferencePoint(2, "Posto 2 - Boqueirão", point(-23.9730, -46.3260)),
                    new ReferencePoint(3, "Posto 3 - Gonzaga", point(-23.9810, -46.3180)),
                    new ReferencePoint(4, "Posto 4 - Gonzaga", point(-23.9890, -46.3100)),
                    new ReferencePoint(5, "Posto 5 - Gonzaga", point(-23.9960, -46.3040)),
                    new ReferencePoint(6, "Posto 6 - José Menino", point(-24.0040, -46.2970)),
                    new ReferencePoint(7, "Posto 7 - Ponta da Praia", point(-24.0180, -46.2900))
            ));
        };
    }

    private static GeoJsonPoint point(double lat, double lng) {
        return new GeoJsonPoint(lng, lat);
    }
}

package com.penaareia.service;

import com.penaareia.dto.ConfirmDeliveryRequest;
import com.penaareia.dto.CreateOrderRequest;
import com.penaareia.model.Courier;
import com.penaareia.model.GeoPoint;
import com.penaareia.model.Order;
import com.penaareia.model.ReferencePoint;
import com.penaareia.repository.CourierRepository;
import com.penaareia.repository.KioskRepository;
import com.penaareia.repository.OrderRepository;
import com.penaareia.repository.ReferencePointRepository;
import com.penaareia.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class OrderService {

    /** Distância máxima permitida entre o pin e o posto de referência vinculado. */
    static final double MAX_DISTANCE_TO_REFERENCE_METERS = 500.0;

    /** Máquina de transições válidas de status do pedido. */
    static final Map<Order.Status, Set<Order.Status>> ALLOWED_TRANSITIONS = Map.of(
            Order.Status.CREATED,    Set.of(Order.Status.PAID, Order.Status.CANCELLED),
            Order.Status.PAID,       Set.of(Order.Status.PREPARING, Order.Status.CANCELLED),
            Order.Status.PREPARING,  Set.of(Order.Status.ON_THE_WAY, Order.Status.CANCELLED),
            Order.Status.ON_THE_WAY, Set.of(Order.Status.DELIVERED),
            Order.Status.DELIVERED,  Set.of(),
            Order.Status.CANCELLED,  Set.of()
    );

    private final OrderRepository orderRepository;
    private final KioskRepository kioskRepository;
    private final UserRepository userRepository;
    private final ReferencePointRepository referencePointRepository;
    private final CourierRepository courierRepository;
    private final double deliveryRadiusMeters;

    public OrderService(OrderRepository orderRepository,
                        KioskRepository kioskRepository,
                        UserRepository userRepository,
                        ReferencePointRepository referencePointRepository,
                        CourierRepository courierRepository,
                        @Value("${penaareia.delivery.radius-meters:50}") double deliveryRadiusMeters) {
        this.orderRepository = orderRepository;
        this.kioskRepository = kioskRepository;
        this.userRepository = userRepository;
        this.referencePointRepository = referencePointRepository;
        this.courierRepository = courierRepository;
        this.deliveryRadiusMeters = deliveryRadiusMeters;
    }

    /**
     * Cria um pedido com pin de entrega na praia.
     * O pin deve estar a no máximo 500 m do posto de referência vinculado.
     */
    public Order createOrder(CreateOrderRequest request) {
        var user = userRepository.findById(request.userId())
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado: " + request.userId()));

        kioskRepository.findById(request.kioskId())
                .orElseThrow(() -> new ResourceNotFoundException("Quiosque não encontrado: " + request.kioskId()));

        ReferencePoint referencePoint = referencePointRepository.findById(request.referencePointId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Posto de referência não encontrado: " + request.referencePointId()));

        validatePinNearReferencePoint(request.deliveryPin(), referencePoint);

        Order order = new Order();
        order.setUserId(request.userId());
        order.setKioskId(request.kioskId());
        order.setItems(toOrderItems(request));
        order.setTotalAmount(calculateTotal(request));
        order.setPaymentMethod(request.paymentMethod());
        order.setDeliveryPin(new GeoJsonPoint(request.deliveryPin().lng(), request.deliveryPin().lat()));
        order.setReferencePointId(request.referencePointId());
        order.setLocationDescription(request.locationDescription());
        order.setLocationPhotoUrl(request.locationPhotoUrl());
        order.setSustainablePackaging(request.sustainablePackaging());

        // Pagamento é sempre antecipado: aqui entraria a confirmação do
        // gateway Pix/cartão; ao criar com sucesso, o pedido já nasce PAGO.
        order.transitionTo(Order.Status.PAID);

        Order saved = orderRepository.save(order);

        user.addOrderId(saved.getId());
        userRepository.save(user);

        return saved;
    }

    /** Atualiza o status respeitando a máquina de transições. */
    public Order updateStatus(String orderId, Order.Status newStatus) {
        Order order = findOrder(orderId);
        Set<Order.Status> allowed = ALLOWED_TRANSITIONS.getOrDefault(order.getStatus(), Set.of());

        if (!allowed.contains(newStatus)) {
            throw new BusinessRuleException(
                    "Transição inválida: " + order.getStatus() + " -> " + newStatus);
        }

        order.transitionTo(newStatus);
        return orderRepository.save(order);
    }

    /**
     * Confirma a entrega: exige que a localização do entregador esteja
     * dentro do raio configurado (penaareia.delivery.radius-meters) do pin.
     * Após confirmar, o entregador volta a ficar disponível.
     */
    public Order confirmDelivery(String orderId, ConfirmDeliveryRequest request) {
        Order order = findOrder(orderId);

        if (order.getStatus() != Order.Status.ON_THE_WAY) {
            throw new BusinessRuleException(
                    "Só é possível confirmar entrega de pedidos a caminho (status atual: "
                            + order.getStatus() + ").");
        }
        if (order.getCourierId() == null || !order.getCourierId().equals(request.courierId())) {
            throw new BusinessRuleException("Este pedido não pertence a este entregador.");
        }

        Courier courier = courierRepository.findById(request.courierId())
                .orElseThrow(() -> new ResourceNotFoundException("Entregador não encontrado: " + request.courierId()));

        GeoPoint pin = new GeoPoint(order.getDeliveryPin().getY(), order.getDeliveryPin().getX());
        double distance = request.courierLocation().distanceInMetersTo(pin);

        if (distance > deliveryRadiusMeters) {
            throw new BusinessRuleException(
                    "Você está a " + Math.round(distance) + " m do pin do cliente. "
                            + "Aproxime-se para confirmar a entrega (máximo "
                            + (int) deliveryRadiusMeters + " m).");
        }

        order.transitionTo(Order.Status.DELIVERED);
        courier.setStatus(Courier.Status.AVAILABLE);
        courierRepository.save(courier);

        return orderRepository.save(order);
    }

    public Order findOrder(String orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido não encontrado: " + orderId));
    }

    private void validatePinNearReferencePoint(GeoPoint pin, ReferencePoint referencePoint) {
        GeoPoint rpLocation = new GeoPoint(
                referencePoint.getLocation().getY(), referencePoint.getLocation().getX());
        double distanceMeters = pin.distanceInMetersTo(rpLocation);
        if (distanceMeters > MAX_DISTANCE_TO_REFERENCE_METERS) {
            throw new BusinessRuleException(
                    "O pin está a " + Math.round(distanceMeters) + " m do posto "
                            + referencePoint.getNumber() + ". Máximo permitido: "
                            + (int) MAX_DISTANCE_TO_REFERENCE_METERS + " m.");
        }
    }

    private List<Order.OrderItem> toOrderItems(CreateOrderRequest request) {
        return request.items().stream()
                .map(i -> new Order.OrderItem(i.menuItemId(), i.name(), i.unitPrice(), i.quantity()))
                .toList();
    }

    private BigDecimal calculateTotal(CreateOrderRequest request) {
        return request.items().stream()
                .map(i -> i.unitPrice().multiply(BigDecimal.valueOf(i.quantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}

package com.penaareia.dto;

import com.penaareia.model.GeoPoint;
import com.penaareia.model.Kiosk;

import java.util.List;

public record KioskResponse(
        String id,
        String name,
        String nearestReferencePointId,
        List<Kiosk.MenuItem> menu,
        GeoPoint location
) {

    public static KioskResponse from(Kiosk k) {
        return new KioskResponse(
                k.getId(), k.getName(), k.getNearestReferencePointId(), k.getMenu(),
                new GeoPoint(k.getLocation().getY(), k.getLocation().getX())
        );
    }
}

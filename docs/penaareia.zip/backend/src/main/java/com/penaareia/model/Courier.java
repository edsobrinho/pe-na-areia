package com.penaareia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "couriers")
public class Courier {

    public enum Status {
        AVAILABLE, ON_ROUTE
    }

    @Id
    private String id;

    private String name;

    /** E-mail usado no login (único). */
    @Indexed(unique = true, sparse = true)
    private String email;

    private String passwordHash;

    /** Pé ou BIKE. */
    private String vehicle;

    private Status status = Status.AVAILABLE;

    @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
    private GeoJsonPoint currentLocation;

    public Courier() {
    }

    public Courier(String name, String vehicle) {
        this.name = name;
        this.vehicle = vehicle;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getVehicle() { return vehicle; }
    public void setVehicle(String vehicle) { this.vehicle = vehicle; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public GeoJsonPoint getCurrentLocation() { return currentLocation; }
    public void setCurrentLocation(GeoJsonPoint currentLocation) { this.currentLocation = currentLocation; }
}

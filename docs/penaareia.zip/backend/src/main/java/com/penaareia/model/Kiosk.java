package com.penaareia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "kiosks")
public class Kiosk {

    /** Item simplificado do cardápio (preço em reais). */
    public record MenuItem(String id, String name, BigDecimal price, boolean available) {
    }

    @Id
    private String id;

    private String name;

    /** Posto de salvamento mais próximo (referência textual/ID). */
    private String nearestReferencePointId;

    private List<MenuItem> menu = new ArrayList<>();

    @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
    private GeoJsonPoint location;

    public Kiosk() {
    }

    public Kiosk(String name, String nearestReferencePointId, GeoJsonPoint location) {
        this.name = name;
        this.nearestReferencePointId = nearestReferencePointId;
        this.location = location;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNearestReferencePointId() { return nearestReferencePointId; }
    public void setNearestReferencePointId(String nearestReferencePointId) { this.nearestReferencePointId = nearestReferencePointId; }
    public List<MenuItem> getMenu() { return menu; }
    public void setMenu(List<MenuItem> menu) { this.menu = menu; }
    public GeoJsonPoint getLocation() { return location; }
    public void setLocation(GeoJsonPoint location) { this.location = location; }
}

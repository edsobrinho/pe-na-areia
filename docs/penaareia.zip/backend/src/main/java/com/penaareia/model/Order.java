package com.penaareia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Document(collection = "orders")
public class Order {

    public enum Status {
        CREATED, PAID, PREPARING, ON_THE_WAY, DELIVERED, CANCELLED
    }

    public enum PaymentMethod {
        PIX, CREDIT_CARD
    }

    /** Item dentro de um pedido: referência ao cardápio + quantidade. */
    public record OrderItem(String menuItemId, String name, BigDecimal unitPrice, int quantity) {
    }

    @Id
    private String id;

    private String userId;

    private String kioskId;

    private List<OrderItem> items = new ArrayList<>();

    private BigDecimal totalAmount;

    private PaymentMethod paymentMethod;

    private Status status = Status.CREATED;

    /** Pin exato onde o cliente está na praia (arrastável no app). */
    @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
    private GeoJsonPoint deliveryPin;

    /** Posto de salvamento escolhido como referência. */
    private String referencePointId;

    /** Descrição curta: "debaixo da sombrinha vermelha, perto da areia". */
    private String locationDescription;

    /** URL da foto opcional do local (Firebase Storage / Cloudinary). */
    private String locationPhotoUrl;

    private boolean sustainablePackaging;

    private String courierId;

    /** Timestamp de cada etapa do fluxo. */
    private Map<Status, Instant> statusTimestamps = new EnumMap<>(Status.class);

    public Order() {
        this.statusTimestamps.put(Status.CREATED, Instant.now());
    }

    public String getId() { return id; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getKioskId() { return kioskId; }
    public void setKioskId(String kioskId) { this.kioskId = kioskId; }
    public List<OrderItem> getItems() { return items; }
    public void setItems(List<OrderItem> items) { this.items = items; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    public Status getStatus() { return status; }
    public GeoJsonPoint getDeliveryPin() { return deliveryPin; }
    public void setDeliveryPin(GeoJsonPoint deliveryPin) { this.deliveryPin = deliveryPin; }
    public String getReferencePointId() { return referencePointId; }
    public void setReferencePointId(String referencePointId) { this.referencePointId = referencePointId; }
    public String getLocationDescription() { return locationDescription; }
    public void setLocationDescription(String locationDescription) { this.locationDescription = locationDescription; }
    public String getLocationPhotoUrl() { return locationPhotoUrl; }
    public void setLocationPhotoUrl(String locationPhotoUrl) { this.locationPhotoUrl = locationPhotoUrl; }
    public boolean isSustainablePackaging() { return sustainablePackaging; }
    public void setSustainablePackaging(boolean sustainablePackaging) { this.sustainablePackaging = sustainablePackaging; }
    public String getCourierId() { return courierId; }
    public void setCourierId(String courierId) { this.courierId = courierId; }
    public Map<Status, Instant> getStatusTimestamps() { return statusTimestamps; }

    /** Transição de status com registro do timestamp da etapa. */
    public void transitionTo(Status newStatus) {
        this.status = newStatus;
        this.statusTimestamps.put(newStatus, Instant.now());
    }
}

package com.penaareia.model;

import jakarta.validation.constraints.NotNull;

/**
 * Ponto geográfico em GeoJSON (type: Point, coordinates: [longitude, latitude]).
 * A ordem das coordenadas é [lng, lat] conforme a especificação GeoJSON.
 */
public record GeoPoint(
        @NotNull(message = "Latitude é obrigatória") Double lat,
        @NotNull(message = "Longitude é obrigatória") Double lng
) {

    /** Estrutura GeoJSON serializada para o MongoDB (índice 2dsphere). */
    public java.util.Map<String, Object> toGeoJson() {
        return java.util.Map.of(
                "type", "Point",
                "coordinates", new Double[]{lng, lat}
        );
    }

    /** Distância em metros até outro ponto (fórmula de Haversine). */
    public double distanceInMetersTo(GeoPoint other) {
        final double EARTH_RADIUS_M = 6371000.0;
        double dLat = Math.toRadians(other.lat() - this.lat());
        double dLng = Math.toRadians(other.lng() - this.lng());
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(this.lat())) * Math.cos(Math.toRadians(other.lat()))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return EARTH_RADIUS_M * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
}

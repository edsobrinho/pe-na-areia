package com.penaareia.controller;

import com.penaareia.dto.ConfirmDeliveryRequest;
import com.penaareia.dto.CreateOrderRequest;
import com.penaareia.dto.OrderResponse;
import com.penaareia.dto.StatusUpdateRequest;
import com.penaareia.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
@Tag(name = "Orders", description = "Criação e acompanhamento de pedidos")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Cria um pedido com pin de entrega na praia e pagamento antecipado")
    public OrderResponse createOrder(@Valid @RequestBody CreateOrderRequest request) {
        return OrderResponse.from(orderService.createOrder(request));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Atualiza o status do pedido (máquina de transições validada)")
    public OrderResponse updateStatus(@PathVariable String id,
                                      @Valid @RequestBody StatusUpdateRequest request) {
        return OrderResponse.from(orderService.updateStatus(id, request.status()));
    }

    @PostMapping("/{id}/confirm-delivery")
    @Operation(summary = "Confirma entrega — exige geolocalização do entregador dentro do raio do pin")
    public OrderResponse confirmDelivery(@PathVariable String id,
                                         @Valid @RequestBody ConfirmDeliveryRequest request) {
        return OrderResponse.from(orderService.confirmDelivery(id, request));
    }
}

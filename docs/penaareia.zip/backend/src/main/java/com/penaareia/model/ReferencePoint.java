package com.penaareia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Posto de Salvamento oficial da orla de Santos.
 * Dado fixo: populado via seed (ReferencePointDataLoader).
 */
@Document(collection = "reference_points")
public class ReferencePoint {

    @Id
    private String id;

    /** Número oficial do posto (ex.: 1, 2, 3...). */
    private Integer number;

    /** Nome de exibição (ex.: "Posto 5 - Gonzaga"). */
    private String name;

    @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
    private GeoJsonPoint location;

    public ReferencePoint() {
    }

    public ReferencePoint(Integer number, String name, GeoJsonPoint location) {
        this.number = number;
        this.name = name;
        this.location = location;
    }

    public String getId() { return id; }
    public Integer getNumber() { return number; }
    public void setNumber(Integer number) { this.number = number; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public GeoJsonPoint getLocation() { return location; }
    public void setLocation(GeoJsonPoint location) { this.location = location; }
}

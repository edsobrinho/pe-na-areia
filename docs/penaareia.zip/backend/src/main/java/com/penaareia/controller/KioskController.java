package com.penaareia.controller;

import com.penaareia.dto.KioskResponse;
import com.penaareia.repository.KioskRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/kiosks")
@Tag(name = "Kiosks", description = "Quiosques e restaurantes parceiros da orla")
public class KioskController {

    private final KioskRepository repository;

    public KioskController(KioskRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    @Operation(summary = "Lista quiosques parceiros (todos ou os mais próximos de um ponto)")
    public List<KioskResponse> list(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(defaultValue = "5000") int radiusMeters) {

        if (lat != null && lng != null) {
            return repository.findNear(new GeoJsonPoint(lng, lat), radiusMeters)
                    .stream().map(KioskResponse::from).toList();
        }
        return repository.findAll().stream().map(KioskResponse::from).toList();
    }
}

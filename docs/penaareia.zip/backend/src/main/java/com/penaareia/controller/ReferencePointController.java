package com.penaareia.controller;

import com.penaareia.dto.ReferencePointResponse;
import com.penaareia.repository.ReferencePointRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reference-points")
@Tag(name = "Reference Points", description = "Postos de salvamento oficiais da orla de Santos")
public class ReferencePointController {

    private final ReferencePointRepository repository;

    public ReferencePointController(ReferencePointRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    @Operation(summary = "Lista todos os postos (ou os mais próximos de um ponto)")
    public List<ReferencePointResponse> list(
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(defaultValue = "3000") int radiusMeters) {

        if (lat != null && lng != null) {
            return repository.findNear(new GeoJsonPoint(lng, lat), radiusMeters)
                    .stream().map(ReferencePointResponse::from).toList();
        }
        return repository.findAll().stream().map(ReferencePointResponse::from).toList();
    }
}

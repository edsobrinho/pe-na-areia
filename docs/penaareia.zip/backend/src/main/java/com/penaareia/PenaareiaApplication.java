package com.penaareia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenaareiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PenaareiaApplication.class, args);
    }
}

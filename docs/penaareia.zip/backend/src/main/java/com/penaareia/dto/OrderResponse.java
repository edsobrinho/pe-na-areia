package com.penaareia.dto;

import com.penaareia.model.GeoPoint;
import com.penaareia.model.Order;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public record OrderResponse(
        String id,
        String userId,
        String kioskId,
        List<Order.OrderItem> items,
        BigDecimal totalAmount,
        Order.PaymentMethod paymentMethod,
        Order.Status status,
        GeoPoint deliveryPin,
        String referencePointId,
        String locationDescription,
        String locationPhotoUrl,
        boolean sustainablePackaging,
        String courierId,
        Map<Order.Status, Instant> statusTimestamps
) {

    public static OrderResponse from(Order o) {
        return new OrderResponse(
                o.getId(), o.getUserId(), o.getKioskId(), o.getItems(), o.getTotalAmount(),
                o.getPaymentMethod(), o.getStatus(),
                new GeoPoint(o.getDeliveryPin().getY(), o.getDeliveryPin().getX()),
                o.getReferencePointId(), o.getLocationDescription(), o.getLocationPhotoUrl(),
                o.isSustainablePackaging(), o.getCourierId(), o.getStatusTimestamps()
        );
    }
}

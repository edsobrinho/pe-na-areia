package com.penaareia.repository;

import com.penaareia.model.ReferencePoint;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReferencePointRepository extends MongoRepository<ReferencePoint, String> {
    /** Postos num raio (metros), ordenados por proximidade. */
    @org.springframework.data.mongodb.repository.Query("{ 'location': { $near: { $geometry: ?0, $maxDistance: ?1 } } }")
    java.util.List<ReferencePoint> findNear(org.springframework.data.mongodb.core.geo.GeoJsonPoint point, int maxDistanceMeters);
}

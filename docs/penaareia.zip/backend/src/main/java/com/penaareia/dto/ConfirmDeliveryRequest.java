package com.penaareia.dto;

import com.penaareia.model.GeoPoint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ConfirmDeliveryRequest(
        @NotBlank String courierId,

        /** Localização atual do entregador, enviada pelo app. */
        @NotNull GeoPoint courierLocation
) {
}

package com.penaareia.service;

import com.penaareia.dto.AuthDtos.LoginRequest;
import com.penaareia.dto.AuthDtos.RegisterRequest;
import com.penaareia.model.User;
import com.penaareia.repository.CourierRepository;
import com.penaareia.repository.UserRepository;
import com.penaareia.security.JwtService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock UserRepository userRepository;
    @Mock CourierRepository courierRepository;
    @Mock PasswordEncoder passwordEncoder;
    @Mock JwtService jwtService;

    @InjectMocks AuthService authService;

    @Test
    void registerClientReturnsToken() {
        when(passwordEncoder.encode("segredo123")).thenReturn("hash");
        when(userRepository.save(any(User.class))).thenAnswer(inv -> {
            User u = inv.getArgument(0);
            u.addOrderId("x"); // hack: setter inexistente, apenas instancia
            return u;
        });
        when(jwtService.generateToken(any(), any(), any())).thenReturn("jwt-token");

        var response = authService.register(new RegisterRequest(
                "Ana", "ana@email.com", "13999990000", "segredo123", "CLIENT", null));

        assertEquals("jwt-token", response.token());
        assertEquals("CLIENT", response.role());
    }

    @Test
    void loginRejectsWrongPassword() {
        User user = new User("Ana", "ana@email.com", "13999990000", "hash");
        when(userRepository.findByEmail("ana@email.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("errada", "hash")).thenReturn(false);

        assertThrows(BusinessRuleException.class, () -> authService.login(
                new LoginRequest("ana@email.com", "errada")));
    }

    @Test
    void registerCourierRequiresVehicle() {
        assertThrows(BusinessRuleException.class, () -> authService.register(
                new RegisterRequest("Rafa", "rafa@email.com", "13999991111", "segredo123", "COURIER", null)));
    }
}

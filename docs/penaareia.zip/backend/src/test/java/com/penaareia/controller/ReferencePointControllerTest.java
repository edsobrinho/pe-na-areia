package com.penaareia.controller;

import com.penaareia.model.ReferencePoint;
import com.penaareia.repository.ReferencePointRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ReferencePointController.class)
@AutoConfigureMockMvc(addFilters = false)   // segurança testada separadamente
class ReferencePointControllerTest {

    @Autowired MockMvc mockMvc;

    @MockBean ReferencePointRepository repository;

    @Test
    void listAllReturnsSeedPosts() throws Exception {
        when(repository.findAll()).thenReturn(List.of(
                new ReferencePoint(1, "Posto 1 - Boqueirão", new GeoJsonPoint(-46.3330, -23.9660)),
                new ReferencePoint(2, "Posto 2 - Boqueirão", new GeoJsonPoint(-46.3260, -23.9730))
        ));

        mockMvc.perform(get("/reference-points"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Posto 1 - Boqueirão"))
                .andExpect(jsonPath("$[1].number").value(2));
    }
}

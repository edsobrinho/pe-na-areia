package com.penaareia.controller;

import com.penaareia.model.Kiosk;
import com.penaareia.repository.KioskRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(KioskController.class)
@AutoConfigureMockMvc(addFilters = false)   // segurança testada separadamente
class KioskControllerTest {

    @Autowired MockMvc mockMvc;

    @MockBean KioskRepository repository;

    @Test
    void listAllReturnsKiosks() throws Exception {
        when(repository.findAll()).thenReturn(List.of(
                new Kiosk("Quiosque do Zé", "rp-3", new GeoJsonPoint(-46.3178, -23.9810))
        ));

        mockMvc.perform(get("/kiosks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Quiosque do Zé"))
                .andExpect(jsonPath("$[0].nearestReferencePointId").value("rp-3"));
    }
}

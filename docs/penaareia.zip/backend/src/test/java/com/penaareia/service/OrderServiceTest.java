package com.penaareia.service;

import com.penaareia.dto.ConfirmDeliveryRequest;
import com.penaareia.dto.CreateOrderRequest;
import com.penaareia.dto.OrderItemRequest;
import com.penaareia.model.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    private static final double RADIUS_METERS = 50.0;

    @Mock OrderRepository orderRepository;
    @Mock KioskRepository kioskRepository;
    @Mock UserRepository userRepository;
    @Mock ReferencePointRepository referencePointRepository;
    @Mock CourierRepository courierRepository;

    @InjectMocks OrderService orderService;

    private CreateOrderRequest validRequest() {
        return new CreateOrderRequest(
                "user-1", "kiosk-1",
                List.of(new OrderItemRequest("item-1", "Água de coco", new BigDecimal("8.00"), 2)),
                Order.PaymentMethod.PIX,
                new GeoPoint(-23.9815, -46.3178),   // pin perto do posto 3
                "rp-3",
                "Sombrinha azul perto da areia",
                null,
                true
        );
    }

    @Test
    void createOrderSuccess() {
        when(userRepository.findById("user-1"))
                .thenReturn(Optional.of(new User("Ana", "ana@email.com", "13999990000", "hash")));
        when(kioskRepository.findById("kiosk-1"))
                .thenReturn(Optional.of(new Kiosk("Quiosque do Zé", "rp-3", new GeoJsonPoint(-46.3178, -23.9810))));
        when(referencePointRepository.findById("rp-3"))
                .thenReturn(Optional.of(new ReferencePoint(3, "Posto 3 - Gonzaga", new GeoJsonPoint(-46.3180, -23.9810))));
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        Order order = orderService.createOrder(validRequest());

        assertEquals(Order.Status.PAID, order.getStatus()); // pagamento antecipado
        assertEquals(new BigDecimal("16.00"), order.getTotalAmount());
        assertTrue(order.isSustainablePackaging());
        assertNotNull(order.getStatusTimestamps().get(Order.Status.CREATED));
    }

    @Test
    void createOrderRejectsPinTooFarFromReferencePoint() {
        CreateOrderRequest request = new CreateOrderRequest(
                "user-1", "kiosk-1",
                List.of(new OrderItemRequest("item-1", "Água de coco", new BigDecimal("8.00"), 1)),
                Order.PaymentMethod.PIX,
                new GeoPoint(-23.9000, -46.4000),   // longe do posto 3
                "rp-3", null, null, false
        );
        when(userRepository.findById("user-1"))
                .thenReturn(Optional.of(new User("Ana", "ana@email.com", "13999990000", "hash")));
        when(kioskRepository.findById("kiosk-1"))
                .thenReturn(Optional.of(new Kiosk("Quiosque do Zé", "rp-3", new GeoJsonPoint(-46.3178, -23.9810))));
        when(referencePointRepository.findById("rp-3"))
                .thenReturn(Optional.of(new ReferencePoint(3, "Posto 3 - Gonzaga", new GeoJsonPoint(-46.3180, -23.9810))));

        assertThrows(BusinessRuleException.class, () -> orderService.createOrder(request));
        verify(orderRepository, never()).save(any());
    }

    @Test
    void updateStatusFollowsAllowedTransitions() {
        Order order = new Order();
        order.transitionTo(Order.Status.PAID);
        when(orderRepository.findById("o1")).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        Order updated = orderService.updateStatus("o1", Order.Status.PREPARING);

        assertEquals(Order.Status.PREPARING, updated.getStatus());
        assertNotNull(updated.getStatusTimestamps().get(Order.Status.PREPARING));
    }

    @Test
    void updateStatusRejectsInvalidTransition() {
        Order order = new Order();
        order.transitionTo(Order.Status.DELIVERED);
        when(orderRepository.findById("o1")).thenReturn(Optional.of(order));

        assertThrows(BusinessRuleException.class,
                () -> orderService.updateStatus("o1", Order.Status.PREPARING));
        verify(orderRepository, never()).save(any());
    }

    @Test
    void confirmDeliverySuccessInsideRadius() {
        Order order = new Order();
        order.transitionTo(Order.Status.PAID);
        order.transitionTo(Order.Status.PREPARING);
        order.transitionTo(Order.Status.ON_THE_WAY);
        order.setCourierId("c1");
        order.setDeliveryPin(new GeoJsonPoint(-46.3178, -23.9815));

        Courier courier = new Courier("Rafa", "PE");
        courier.setStatus(Courier.Status.ON_ROUTE);

        when(orderRepository.findById("o1")).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));
        when(courierRepository.findById("c1")).thenReturn(Optional.of(courier));
        when(courierRepository.save(any(Courier.class))).thenAnswer(inv -> inv.getArgument(0));

        // entregador a ~20 m do pin
        var result = orderService.confirmDelivery("o1",
                new ConfirmDeliveryRequest("c1", new GeoPoint(-23.9813, -46.3177)));

        assertEquals(Order.Status.DELIVERED, result.getStatus());
        assertEquals(Courier.Status.AVAILABLE, courier.getStatus());
    }

    @Test
    void confirmDeliveryRejectsWhenOutsideRadius() {
        Order order = new Order();
        order.transitionTo(Order.Status.ON_THE_WAY);
        order.setCourierId("c1");
        order.setDeliveryPin(new GeoJsonPoint(-46.3178, -23.9815));

        Courier courier = new Courier("Rafa", "PE");

        when(orderRepository.findById("o1")).thenReturn(Optional.of(order));
        when(courierRepository.findById("c1")).thenReturn(Optional.of(courier));

        // entregador a ~400 m do pin
        assertThrows(BusinessRuleException.class, () -> orderService.confirmDelivery("o1",
                new ConfirmDeliveryRequest("c1", new GeoPoint(-23.9845, -46.3200))));
        verify(orderRepository, never()).save(any());
    }

    @Test
    void confirmDeliveryRejectsWrongCourier() {
        Order order = new Order();
        order.transitionTo(Order.Status.ON_THE_WAY);
        order.setCourierId("c2");

        when(orderRepository.findById("o1")).thenReturn(Optional.of(order));

        assertThrows(BusinessRuleException.class, () -> orderService.confirmDelivery("o1",
                new ConfirmDeliveryRequest("c1", new GeoPoint(-23.9815, -46.3178))));
    }
}
